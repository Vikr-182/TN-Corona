sudo /usr/bin/python3 main.py;
sudo /usr/bin/python3 convert.py;
sudo /usr/bin/python3 rename.py;
